﻿<?php

//get necessary includes:
include_once ("installactions.php");
include_once ("installfunctions.php");
include_once ("installeditforms.php");

//specify the variables we are going to use:
$script_variables  = array('install_step',
                           'migrate_from_old');

$install_variables = array('AIGAION1_DB_HOST',
                           'AIGAION1_DB_USER',
                           'AIGAION1_DB_PWD',
                           'AIGAION1_DB_NAME',
                           'AIGAION2_DB_HOST',
                           'AIGAION2_DB_USER',
                           'AIGAION2_DB_PWD',
                           'AIGAION2_DB_NAME',
                           'AIGAION2_DB_PREFIX',
                           'AIGAION_ROOT_URL',
                           'AIGAION_ROOT_DIR',
                           'AIGAION_SITEID',
                           'AIGAION_ENGINE_URL',
                           'AIGAION_ATTACHMENT_DIR',
                           'AIGAION_ATTACHMENT_URL');

$vars   = array_merge($script_variables, $install_variables);;

//retrieve variables from post:
foreach ($vars as $var)
{
  $values[$var] = NULL;
  if (isset($_REQUEST[$var])) {
    $values[$var] = $_REQUEST[$var];
  }
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Aigaion 2.0 - A multi user annotated bibliography - Installer</title>
    <link href="../aigaionengine/themes/default/css/styling.css"     rel="stylesheet" type="text/css" media="screen,projection,tv" />
  </head>
  <body>
<?php

if (!isset($values['install_step']))
{
  getMainInstallForm($vars, $values);
}
if ($values['install_step'] == 'step2')
{
  if ($values['migrate_from_old'])
  {
    //call migration form
    getMigrationForm($vars, $values);
  }
  else
  {
    //call install form
    getNewInstallForm($vars, $values);
  }
}

if ($values['install_step'] == 'step3')
{
  if ($values['migrate_from_old'])
  {
    //migrate database
    migrateOldDatabase($values['AIGAION1_DB_HOST'],
                       $values['AIGAION1_DB_USER'], 
                       $values['AIGAION1_DB_PWD'], 
                       $values['AIGAION1_DB_NAME'], 
                       $values['AIGAION2_DB_HOST'], 
                       $values['AIGAION2_DB_USER'], 
                       $values['AIGAION2_DB_PWD'], 
                       $values['AIGAION2_DB_NAME'], 
                       $values['AIGAION2_DB_PREFIX']);    
  }
  else
  {
    //create new database
    installNewDatabase($values['AIGAION2_DB_HOST'], 
                       $values['AIGAION2_DB_USER'], 
                       $values['AIGAION2_DB_PWD'], 
                       $values['AIGAION2_DB_NAME'], 
                       $values['AIGAION2_DB_PREFIX']);
  }
  
  getSiteConfigurationForm($vars, $values);
}
if ($values['install_step'] == 'step4')
{
  writeIndexFile($values['AIGAION2_DB_HOST'], 
                 $values['AIGAION2_DB_USER'],
                 $values['AIGAION2_DB_PWD'], 
                 $values['AIGAION2_DB_NAME'], 
                 $values['AIGAION2_DB_PREFIX'], 
                 $values['AIGAION_SITEID'],
                 $values['AIGAION_ROOT_URL'],
                 $values['AIGAION_ROOT_DIR'], 
                 $values['AIGAION_ENGINE_URL'], 
                 $values['AIGAION_ATTACHMENT_URL'], 
                 $values['AIGAION_ATTACHMENT_DIR']);
                 
?>
<div class=editform>
  <p class=header>Installing Aigaion - Installation complete</p>
  <p>That's it, Aigaion is now installed and ready to use.
<?php
  if ($values['migrate_from_old'])
    echo "The accounts from your old Aigaion installation are also available in this new installation, so log in and enjoy the show!";
  else
  {
    echo "You can login using the admin account:<br/>";
    echo "Username: 'admin'<br/>";
    echo "Password: 'admin'</br/>";
    echo "Please change this account name and password after logging in.";
  }
?>
  </p>
  <p><b>IMPORTANT:</b> please remove the /install directory completely to prevent other people accessing your system.</p>
  <p><a href="../">Proceed to login!</a></p>
</div>
<?php
}

?>
  </body>
</html>